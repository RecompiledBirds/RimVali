﻿using System;

namespace HARPATCHES
{
    public class Class1
    {
    }
}
