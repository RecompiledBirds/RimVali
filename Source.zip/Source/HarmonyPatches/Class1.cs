﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RimWorld;
using Verse;
using HarmonyLib;
namespace AvaliMod
{
	[HarmonyPatch(typeof(CreditsAssembler), "AllCredits")]
	public class Credits
	{
		public static List<String> artists = new List<string> { "Zentimental (@Zentimental_ on twitter)", "Todd The Avali (@ToddHusky on twitter)" };
		public static List<String> programmers = new List<string> { "LiQd", "Nesi (@Nesi_The_Avali on twitter)" };
		public static List<String> testers = new List<string> { "Aipi avali (@AipiTheAvali on twitter)", "Ammery", "Anarchy (@AnarchyAvali on twitter)", "Altair", "Ciraus", "CakeTaco (@Caketacowo on twitter)", "Dwaggy", "Danny (@DannyAvali on twitter/twitch)", "Diamond_", "Eilani <SomeFoxy>", "Jaffer Roshak (@JafferRoshak on twitter)", "K'braid (@Braiden_Krahn on twitter)", "Nova_", "Nyinxie","RitualNeo (@RitualNeo on twitter/twitch)","SoulblazerRP/Eimilian (@SoulblazerRP on twitter/youtube", "TheHopelessThrumbo", "ZukoTheAvali" };
		public static List<String> contributors = new List<string> { "DimasW","Danny" ,"K'braid" };
		[HarmonyPostfix]
		public static IEnumerable<CreditsEntry> CreditsPatch(IEnumerable<CreditsEntry> __result)
		{
			foreach (CreditsEntry creditsEntry in __result)
			{
				yield return creditsEntry;
				CreditRecord_Role creditRecord_Role = creditsEntry as CreditRecord_Role;
				if (creditRecord_Role != null && creditRecord_Role.creditee.Equals("Many other gracious volunteers!"))
				{

					yield return new CreditRecord_Space(150f);
					yield return new CreditRecord_Title("RimVali would like to thank several people:");
					yield return new CreditRecord_Space(150f);
					yield return new CreditRecord_Title("The artists, who made the amazing textures:");
					foreach (string artist in artists)
                    {
						yield return new CreditRecord_Role(null,artist);
                    }
					yield return new CreditRecord_Space(150f);
					yield return new CreditRecord_Title("Programmers, who wrote the stuff that makes the mod:");
					foreach (string programmer in programmers)
					{
						yield return new CreditRecord_Role(null, programmer);
					}
					yield return new CreditRecord_Space(150f);
					yield return new CreditRecord_Title("The testers, who put up with all the bugs:");
					foreach (string tester in testers)
					{
						yield return new CreditRecord_Role(null, tester);
					}
					yield return new CreditRecord_Space(150f);
					yield return new CreditRecord_Title("Contributors, who helped refine the mod:");
					foreach (string contributor in contributors)
					{
						yield return new CreditRecord_Role(null, contributor);
					}
					yield return new CreditRecord_Title("Thank you all. This mod would not exist today without everyone.");
				}

			}
		}
	}
}
