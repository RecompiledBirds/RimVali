﻿using RimWorld;
using Verse;
using System.Collections.Generic;
using UnityEngine;

namespace AvaliMod
{
    public class graphics
    {
        public string skinColorSet;

        public string bodyTex;
        public string headTex;
        public string skeleton = "Things/Pawn/Humanlike/HumanoidDessicated";
        public string skull = "Things/Pawn/Humanlike/Heads/None_Average_Skull";
        public string stump = "Things/Pawn/Humanlike/Heads/None_Average_Stump";
        public headOffset headOffsets = new headOffset();
        public Vector2 headSize;
        public Vector2 bodySize = new Vector2(1f, 1f);
        public List<Colors> colorSets;
    }
    public class headOffset
    {
        public Vector2 south = new Vector2(0, 0);
        public Vector2 east;
        public Vector2 north;
        public Vector2 west;
        public headOffset()
        {
            if(east == null)
            {
                east = south;
            }if(north == null)
            {
                north = south;
            }if(west == null)
            {
                west = east;
            }
        }
    }
    public class restrictions
    {
        public List<ResearchProjectDef> researchProjectDefs = new List<ResearchProjectDef>();
        //ThingDefs
        public List<ThingDef> equippables = new List<ThingDef>();
        public List<ThingDef> consumables = new List<ThingDef>();
        public List<ThingDef> buildables = new List<ThingDef>();
        public List<ThingDef> bedDefs = new List<ThingDef>();
        //Thoughts
        public List<ThoughtDef> thoughtDefs = new List<ThoughtDef>();
        public List<ThoughtDef> thoughtBlacklist = new List<ThoughtDef>();

        //Traits
        public List<TraitDef> traits = new List<TraitDef>();
        public List<TraitDef> disabledTraits = new List<TraitDef>();

        //Bodytypes
        public List<BodyTypeDef> bodyTypes = new List<BodyTypeDef>();
        //Are these whitelists?
        public bool researchProjectDefsIsWhiteList = false;
        public bool thoughtDefsIsWhiteList = false;
        public bool traitsIsWhiteList = false;

        public bool canOnlyUseApprovedApparel = false;
        //Whitelists
        public List<ThingDef> equippablesWhitelist = new List<ThingDef>();
        public List<ThingDef> consumablesWhitelist = new List<ThingDef>();
        public List<ThingDef> buildablesWhitelist = new List<ThingDef>();

        //Mod lists
        public List<string> modContentRestrictionsApparelWhiteList = new List<string>();
    }

    public class Main
    {
        public restrictions restrictions= new restrictions();
        public graphics graphics = new graphics();

        public List<BodyTypeDef> bodyTypeDefs = new List<BodyTypeDef>();
    }

    public class BodyPartGraphicPos
    {
        public Vector2 position = new Vector2(0f,0f);
        public float layer = 1f;
        public Vector2 size = new Vector2(1f,1f);
      
    }

    public class ColorSet : IExposable
    {
        public Color colorOne;
        public Color colorTwo;
        public Color colorThree;

        public ColorSet(Color colorOne, Color colorTwo, Color colorThree)
        {
            this.colorOne = colorOne;
            this.colorTwo = colorTwo;
            this.colorThree = colorThree;
        }

        public void ExposeData()
        {
            Scribe_Values.Look(ref colorOne, "colorOne");
            Scribe_Values.Look(ref colorTwo, "colorTwo");
            Scribe_Values.Look(ref colorThree, "colorThree");
        }
    }

    public class Colors
    {
        public string name;
        public TriColor_ColorGenerators colorGenerator;
        public TriColor_ColorGenerators colorGeneratorFemale;
    }

    public class TriColor_ColorGenerators
    {
        public ColorGenerator firstColor;
        public ColorGenerator secondColor;
        public ColorGenerator thirdColor;
    }
    
    public class colorComp : ThingComp
    {
        public Dictionary<string, ColorSet> colors = new Dictionary<string, ColorSet>();
        /*public override 
        {
            Scribe_Collections.Look<string, ColorSet>(ref colors, "colors");
            if (colors==null)
            {
                colors = new Dictionary<string, ColorSet>();
            }
        }*/
    }
    public class colorCompProps : CompProperties
    {
        public colorCompProps()
        {
            this.compClass = typeof(colorComp);
        }
    }
    public class Entry
    {
        public PawnKindDef pawnkind;
        public int chance = 50;
        public bool isSlave = true;
        public bool isRefugee = true;
        public bool isWanderer = true;
        public bool isVillager = true;
    }
    public class RVRRaceInsertion
    {
        public int globalChance = 50;
        public List<Entry> entries = new List<Entry>();
    }
}  