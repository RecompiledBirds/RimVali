﻿using System;
using System.Collections.Generic;
using Verse;
using RimWorld;
namespace AvaliMod
{
    public class Slot
    {
        public string name;
        public int size = 1;
        public int curSize = 0;
    }
}
