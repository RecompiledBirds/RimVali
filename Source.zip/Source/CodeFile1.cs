﻿using RimWorld;
using Verse;
namespace AvaliMod
{
    public class ModuleDef : Def
    { 
        public string name;
    }
}